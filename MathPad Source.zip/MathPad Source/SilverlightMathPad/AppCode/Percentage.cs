﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace SilverlightMathPad
{
    abstract class Percentage : Quiz
    {
        protected int number_1, number_2;
        protected int Answer;
        abstract protected int generateNumber_1();
        abstract protected int generateNumber_2();
        abstract protected int generateAnswer();

        public Percentage()
        {
            createQuestionPrototype();
        }
    }

    class Level1Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("What is number_1% of number_2?");

        }

        protected override String createQuestion()
        {
            number_1 = generateNumber_1();
            number_2 = generateNumber_2();


            while (number_2 == 100)
            {

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * number_2) / 100);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(1, 4);
            Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {

            string Num = randomDigit(1, 5).ToString();
            Num = Num + ".";
            //int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            Num = Num + randomDigit(0, 5).ToString();
            return Convert.ToInt16((Convert.ToDecimal(Num) * 100));
        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }



      

    }

    class Level4Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("What is number_1% of number_2?");

        }

        protected override String createQuestion()
        {
            number_1 = generateNumber_1();
            number_2 = generateNumber_2();


            while (number_2 == 100)
            {

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * number_2) / 100);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(3, 7);
            Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {

            string Num = randomDigit(1, 5).ToString();
            Num = Num + ".";
            //int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            Num = Num + randomDigit(0, 5).ToString();
            return Convert.ToInt16((Convert.ToDecimal(Num) * 100));
        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }




    }
  
    class Level8Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("What is number_1% of number_2?");

        }

        protected override String createQuestion()
        {
            number_1 = generateNumber_1();
            number_2 = generateNumber_2();


            while (number_2 == 100)
            {

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * number_2) / 100);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(7, 10);
            Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {

            string Num = randomDigit(1, 10).ToString();
            Num = Num + ".";
            //int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            Num = Num + randomDigit(0, 10).ToString();
            return Convert.ToInt16((Convert.ToDecimal(Num) * 100));
        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }



    }



    class Level2Percentage : Percentage
    {
        protected override String createQuestion()
        {
            Answer = generateAnswer();
            while (Answer == 100)
            {
                Answer = generateAnswer();
            }


            number_1 = generateNumber_1();
            number_2 = generateNumber_2();

            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }
        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("What percent of number_1 is number_2?</b>");

        }
        protected override int generateAnswer()
        {
            string Num = randomDigit(1, 5).ToString();
            Num = Num + ".";
            //int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            Num = Num + randomDigit(0, 5).ToString();
            return Convert.ToInt16((Convert.ToDecimal(Num) * 100));
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(1, 4);
            Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            return Convert.ToInt16((number_1 * Answer) / 100);
        }

        protected override string createAnswer()
        {
            return Answer.ToString() + "%";
        }

        protected override List<String> createOptions()
        {


            //List<String> options = new List<String>();

            //decimal type1, type2;
            //type1 = (randomDigit(1, 2) == 1) ? 1 : -1;
            //type2 = (randomDigit(3, 4) == 1) ? 10 : -10;

            //options.Add(Answer.ToString() + "%");
            //options.Add((Answer + (type1 * 10)).ToString() + "%");
            //options.Add((Answer - (type1 * 10)).ToString() + "%");
            //options.Add((Answer + (type2 * 10)).ToString() + "%");

            //return options;

            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString() + "%");

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;

        }


 

    }

    class Level5Percentage : Percentage
    {
        protected override String createQuestion()
        {
            Answer = generateAnswer();
            while (Answer == 100)
            {
                Answer = generateAnswer();
            }


            number_1 = generateNumber_1();
            number_2 = generateNumber_2();

            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }
        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("What percent of number_1 is number_2?");

        }
        protected override int generateAnswer()
        {
            string Num = randomDigit(1, 5).ToString();
            Num = Num + ".";
            //int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            Num = Num + randomDigit(0, 5).ToString();
            return Convert.ToInt16((Convert.ToDecimal(Num) * 100));
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(3, 7);
            Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            return Convert.ToInt16((number_1 * Answer) / 100);
        }

        protected override string createAnswer()
        {
            return Answer.ToString() + "%";
        }

        protected override List<String> createOptions()
        {


            //List<String> options = new List<String>();

            //decimal type1, type2;
            //type1 = (randomDigit(1, 2) == 1) ? 1 : -1;
            //type2 = (randomDigit(3, 4) == 1) ? 10 : -10;

            //options.Add(Answer.ToString() + "%");
            //options.Add((Answer + (type1 * 10)).ToString() + "%");
            //options.Add((Answer - (type1 * 10)).ToString() + "%");
            //options.Add((Answer + (type2 * 10)).ToString() + "%");

            //return options;

            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString() + "%");

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;

        }

 

    }

    class Level9Percentage : Percentage
    {
        protected override String createQuestion()
        {
            Answer = generateAnswer();
            while (Answer == 100)
            {
                Answer = generateAnswer();
            }


            number_1 = generateNumber_1();
            number_2 = generateNumber_2();

            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }
        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("What percent of number_1 is number_2?");

        }
        protected override int generateAnswer()
        {
            string Num = randomDigit(1, 10).ToString();
            Num = Num + ".";
            //int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            Num = Num + randomDigit(0, 10).ToString();
            return Convert.ToInt16((Convert.ToDecimal(Num) * 100));
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(7, 10);
            Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            return Convert.ToInt16((number_1 * Answer) / 100);
        }

        protected override string createAnswer()
        {
            return Answer.ToString() + "%";
        }

        protected override List<String> createOptions()
        {


            //List<String> options = new List<String>();

            //decimal type1, type2;
            //type1 = (randomDigit(1, 2) == 1) ? 1 : -1;
            //type2 = (randomDigit(3, 4) == 1) ? 10 : -10;

            //options.Add(Answer.ToString() + "%");
            //options.Add((Answer + (type1 * 10)).ToString() + "%");
            //options.Add((Answer - (type1 * 10)).ToString() + "%");
            //options.Add((Answer + (type2 * 10)).ToString() + "%");

            //return options;

            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString() + "%");

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;

        }

    }




    class Level3Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("number_2% of what is number_1?");
        }

        protected override String createQuestion()
        {


            number_1 = generateNumber_1();

            number_2 = generateNumber_2();

            decimal N = number_1 * 100;
            while ((Convert.ToInt16((number_1 * 100) / number_2)).ToString() != (Convert.ToDecimal(N / number_2)).ToString())
            {
                number_1 = generateNumber_1();

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * 100) / number_2);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(1, 6);
            // Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            string Num = randomDigit(1, 9).ToString();
            // Num = Num + ".";
            int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            if (type == 0)
                Num = Num + "0";
            else
                Num = Num + "5";
            return Convert.ToInt16(Num);

        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }



    }

    class Level6Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("number_2% of what is number_1?");
        }

        protected override String createQuestion()
        {


            number_1 = generateNumber_1();

            number_2 = generateNumber_2();

            decimal N = number_1 * 100;
            while ((Convert.ToInt16((number_1 * 100) / number_2)).ToString() != (Convert.ToDecimal(N / number_2)).ToString())
            {
                number_1 = generateNumber_1();

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * 100) / number_2);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(5, 10);
            // Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            string Num = randomDigit(1, 9).ToString();
            // Num = Num + ".";
            int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            if (type == 0)
                Num = Num + "0";
            else
                Num = Num + "5";
            return Convert.ToInt16(Num);

        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }




    }

    class Level7Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("number_2% of what is number_1?");
        }

        protected override String createQuestion()
        {


            number_1 = generateNumber_1();

            number_2 = generateNumber_2();

            decimal N = number_1 * 100;
            while ((Convert.ToInt16((number_1 * 100) / number_2)).ToString() != (Convert.ToDecimal(N / number_2)).ToString())
            {
                number_1 = generateNumber_1();

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * 100) / number_2);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(10, 16);
            // Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            string Num = randomDigit(1, 9).ToString();
            // Num = Num + ".";
            int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            if (type == 0)
                Num = Num + "0";
            else
                Num = Num + "5";
            return Convert.ToInt16(Num);

        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }




    }

    class Level10Percentage : Percentage
    {

        protected override void createQuestionPrototype()
        {
            questionPrototype.Add("number_2% of what is number_1?");
        }

        protected override String createQuestion()
        {


            number_1 = generateNumber_1();

            number_2 = generateNumber_2();

            decimal N = number_1 * 100;
            while ((Convert.ToInt16((number_1 * 100) / number_2)).ToString() != (Convert.ToDecimal(N / number_2)).ToString())
            {
                number_1 = generateNumber_1();

                number_2 = generateNumber_2();
            }

            Answer = generateAnswer();


            String s = questionPrototype.ElementAt(0);
            StringBuilder question = new StringBuilder(s);
            question.Replace("number_1", number_1.ToString());
            question.Replace("number_2", number_2.ToString());
            return question.ToString();
        }

        protected override int generateAnswer()
        {
            return Convert.ToInt16((number_1 * 100) / number_2);
        }

        protected override int generateNumber_1()
        {
            int Num = randomDigit(15, 20);
            // Num = Num * 10;
            return Num;
        }

        protected override int generateNumber_2()
        {
            string Num = randomDigit(1, 9).ToString();
            // Num = Num + ".";
            int type = randomDigit(0, 2);
            //for (int i = type; i > 0; i--)
            if (type == 0)
                Num = Num + "0";
            else
                Num = Num + "5";
            return Convert.ToInt16(Num);

        }

        protected override string createAnswer()
        {
            return Answer.ToString();
        }

        protected override List<String> createOptions()
        {
            int type = -randomDigit(0, 4);
            List<String> options = new List<String>();

            for (int i = 0; i < 4; i++)
                options.Add((Answer + type + i).ToString());

            if (options.Contains("-1"))
            {
                options.Remove("-1");
                options.Add("3");
            }

            return options;
        }



    }

}
